namespace CRUD_Aluno.Api.Controllers.Outputs
{
    public class AlunoListagem
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public int Curso { get; set; }
        public string Cidade { get; set; }
    }
}