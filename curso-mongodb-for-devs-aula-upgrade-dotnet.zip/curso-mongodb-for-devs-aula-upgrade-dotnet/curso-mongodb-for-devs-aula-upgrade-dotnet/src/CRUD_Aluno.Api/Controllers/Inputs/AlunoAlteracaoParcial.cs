namespace CRUD_Aluno.Api.Controllers.Inputs
{
    public class AlunoAlteracaoParcial
    {
        public int Curso { get; set; }
    }
}